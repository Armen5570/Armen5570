#!/usr/bin/env python3
"""Build an isometric SVG city from a GitHub user's contribution calendar."""
import json
import os
import urllib.request
from datetime import datetime, timedelta, timezone
from html import escape

USERNAME = os.getenv("GITHUB_USERNAME", "Armen5570")
TOKEN = os.getenv("GITHUB_TOKEN")
if not TOKEN:
    raise SystemExit("GITHUB_TOKEN is missing.")

now = datetime.now(timezone.utc)
start = (now - timedelta(days=364)).replace(hour=0, minute=0, second=0, microsecond=0)
query = """
query($login: String!, $from: DateTime!, $to: DateTime!) {
  user(login: $login) {
    contributionsCollection(from: $from, to: $to) {
      contributionCalendar {
        totalContributions
        weeks { contributionDays { date contributionCount } }
      }
    }
  }
}
"""
payload = {
    "query": query,
    "variables": {
        "login": USERNAME,
        "from": start.isoformat().replace("+00:00", "Z"),
        "to": now.isoformat().replace("+00:00", "Z"),
    },
}
request = urllib.request.Request(
    "https://api.github.com/graphql",
    data=json.dumps(payload).encode(),
    headers={
        "Authorization": f"Bearer {TOKEN}",
        "Content-Type": "application/json",
        "User-Agent": "contribution-city-generator",
    },
)
with urllib.request.urlopen(request, timeout=30) as response:
    result = json.load(response)
if result.get("errors"):
    raise SystemExit("GitHub GraphQL error: " + json.dumps(result["errors"]))
user = result.get("data", {}).get("user")
if not user:
    raise SystemExit(f"GitHub user not found: {USERNAME}")

calendar = user["contributionsCollection"]["contributionCalendar"]
weeks = calendar["weeks"]
days = [(wi, di, day) for wi, week in enumerate(weeks)
        for di, day in enumerate(week["contributionDays"])]
total = calendar["totalContributions"]
peak = max((d["contributionCount"] for _, _, d in days), default=0)

def colors(n):
    if n == 0: return ("#26364b", "#1b293c", "#34475f")
    if n <= 2: return ("#0e665d", "#0a4d49", "#159b80")
    if n <= 5: return ("#16876b", "#0d604f", "#28c58a")
    if n <= 9: return ("#27b879", "#16885e", "#62e6a2")
    return ("#72f0ae", "#2ba878", "#b0ffd0")

def height(n):
    return 2 if n == 0 else 7 + (n / peak) ** 0.65 * 52 if peak else 7

svg = [
'<svg xmlns="http://www.w3.org/2000/svg" width="100%" viewBox="0 0 1000 650" role="img" aria-labelledby="title desc">',
'<title id="title">GitHub Contribution City</title>',
f'<desc id="desc">{total} contributions by {escape(USERNAME)} over the last year.</desc>',
'<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#07111f"/><stop offset="1" stop-color="#101d30"/></linearGradient><linearGradient id="glow" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#47f0ad" stop-opacity=".16"/><stop offset="1" stop-color="#47f0ad" stop-opacity="0"/></linearGradient></defs>',
'<rect width="1000" height="650" rx="22" fill="url(#bg)"/>',
'<ellipse cx="500" cy="350" rx="410" ry="190" fill="url(#glow)"/>',
'<text x="500" y="52" fill="#f2f7ff" font-family="Arial,sans-serif" font-size="25" font-weight="700" text-anchor="middle">CONTRIBUTION CITY</text>',
f'<text x="500" y="80" fill="#8fa6bd" font-family="Arial,sans-serif" font-size="13" text-anchor="middle">{escape(USERNAME)} • {total:,} contributions • LAST 365 DAYS</text>',
]
for wi, di, day in sorted(days, key=lambda item: item[0] + item[1]):
    n = day["contributionCount"]
    x = 500 + (wi - di) * 12.2
    y = 130 + (wi + di) * 5.7
    h = height(n)
    roof, left, right = colors(n)
    svg.append(
        f'<polygon points="{x:.1f},{y-3:.1f} {x+6:.1f},{y:.1f} {x:.1f},{y+3:.1f} {x-6:.1f},{y:.1f}" fill="#1b2b40" stroke="#263c54" stroke-width=".45"/>'
    )
    svg.append(
        f'<g><title>{day["date"]}: {n} contribution(s)</title>'
        f'<polygon points="{x-5:.1f},{y-h:.1f} {x:.1f},{y-h+2.8:.1f} {x:.1f},{y+2.8:.1f} {x-5:.1f},{y:.1f}" fill="{left}"/>'
        f'<polygon points="{x:.1f},{y-h+2.8:.1f} {x+5:.1f},{y-h:.1f} {x+5:.1f},{y:.1f} {x:.1f},{y+2.8:.1f}" fill="{right}"/>'
        f'<polygon points="{x-5:.1f},{y-h:.1f} {x:.1f},{y-h-2.8:.1f} {x+5:.1f},{y-h:.1f} {x:.1f},{y-h+2.8:.1f}" fill="{roof}"/></g>'
    )
svg += [
'<text x="500" y="610" fill="#6f879f" font-family="Arial,sans-serif" font-size="11" text-anchor="middle">Each building = one day • Building height = contribution count</text>',
'<text x="500" y="630" fill="#526b84" font-family="Arial,sans-serif" font-size="10" text-anchor="middle">AUTO-GENERATED FROM GITHUB CONTRIBUTION DATA</text>',
'</svg>',
]
os.makedirs("assets", exist_ok=True)
with open("assets/contribution-city.svg", "w", encoding="utf-8") as f:
    f.write("\n".join(svg))
print(f"Generated city for {USERNAME}: {total} contributions.")
